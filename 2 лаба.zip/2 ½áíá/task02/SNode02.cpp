// Copyright (c) 2026. Shvalev Dmitrij

#include "SNode02.h"

// Initialize the node with the given value; the link is set to nullptr
SNode::SNode(int _Data) : Data(_Data), Next(nullptr) {
}
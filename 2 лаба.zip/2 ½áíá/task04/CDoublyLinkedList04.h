// Copyright (c) 2026. Shvalev Dmitrij

#pragma once

#include <string>
using namespace std;

struct SNode;

// Class for working with a doubly linked list
class CDoublyLinkedList {
public:
    CDoublyLinkedList();
    ~CDoublyLinkedList();

    void Initialize();                               // Reset the list to an empty state
    void AddElement(int _Value);                     // Append an element to the tail
    void RemoveElement(SNode* _NodeToRemove);        // Remove the specified node
    void Print() const;                              // Print the list to the screen
    void WriteToFileAndClear(const string& _FileName); // Write in reverse order and clear
    void Clear();                                    // Delete all nodes

private:
    SNode* Head; // Pointer to the first node
};